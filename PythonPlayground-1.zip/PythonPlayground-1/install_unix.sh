#!/bin/bash
echo "Installing python-docx library for DOCX Tool..."
pip install python-docx
echo ""
echo "Installation complete!"
echo ""
echo "You can now run the tool using:"
echo "python docx_tool_cli.py"